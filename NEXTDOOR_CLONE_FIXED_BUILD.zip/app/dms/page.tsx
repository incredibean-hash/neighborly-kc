
'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import Link from 'next/link';
function getSupabase(){
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if(!url || !key) return null;
  return createClient(url, key);
}
function formatRelativeLocal(iso:string){ try{ const d=new Date(iso); return d.toLocaleString(); }catch{ return iso; } }
export default function DMsPage(){
  const [supabase,setSupabase]=useState<any>(null);
  const [profile,setProfile]=useState<any>(null);
  const [dms,setDms]=useState<any[]>([]);
  const [selected,setSelected]=useState<string|null>(null);
  const [reply,setReply]=useState('');
  useEffect(()=>{
    setSupabase(getSupabase());
    const s=localStorage.getItem('nkc_profile_tiered_40')||localStorage.getItem('nkc_profile');
    if(s) try{ setProfile(JSON.parse(s)); }catch{}
  },[]);
  const loadDMs = async ()=>{
    if(!supabase || !profile?.full_name) return;
    const {data}=await supabase.from('dms').select('*').or(`from_user.eq.${profile.full_name},to_user.eq.${profile.full_name}`).order('created_at',{ascending:false}).limit(200);
    if(data) setDms(data);
  };
  useEffect(()=>{ if(supabase && profile) loadDMs(); },[supabase, profile]);
  const convos: Record<string, any[]> = {};
  dms.forEach((m:any)=>{ const other = m.from_user===profile?.full_name ? m.to_user : m.from_user; if(!convos[other]) convos[other]=[]; convos[other].push(m); });
  const activeMessages = selected ? (convos[selected]||[]).slice().reverse() : [];
  const sendReply = async ()=>{
    if(!supabase || !selected || !reply.trim()) return;
    const msg=reply.trim(); setReply('');
    await supabase.from('dms').insert({ from_user:profile.full_name, to_user:selected, message:msg, body:msg });
    loadDMs();
  };
  if(!profile) return <div className="min-h-screen p-6"><Link href="/">← Back</Link><p>Join first</p></div>;
  return (
    <div className="min-h-screen bg-[#f8f5ee]"><header className="bg-white border-b p-3 flex justify-between"><Link href="/" className="font-black">← Feed</Link><span className="text-xs">{profile.full_name}</span></header>
    <div className="max-w-6xl mx-auto grid grid-cols-[320px_1fr] gap-4 p-4"><div className="bg-white rounded-2xl border overflow-hidden">{Object.keys(convos).map(other=><button key={other} onClick={()=>setSelected(other)} className="w-full text-left p-4 border-b">{other}</button>)}</div>
    <div className="bg-white rounded-2xl border p-4"><div className="space-y-2">{activeMessages.map((m:any)=><div key={m.id} className={m.from_user===profile.full_name?'text-right':''}><span className="bg-[#f8f5ee] px-3 py-2 rounded-xl inline-block">{m.message}</span></div>)}</div><div className="flex gap-2 mt-4"><input value={reply} onChange={e=>setReply(e.target.value)} className="flex-1 border rounded-full px-4 py-2"/><button onClick={sendReply} className="bg-black text-white px-4 py-2 rounded-full">Send</button></div></div></div></div>
  );
}
