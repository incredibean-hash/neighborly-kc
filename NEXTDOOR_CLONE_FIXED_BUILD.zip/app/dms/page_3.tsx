
'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import Link from 'next/link';

function getSupabase(){
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if(!url || !key) return null;
  return createClient(url, key);
}
function formatRelativeLocal(iso:string){ try{ const d=new Date(iso); const now=new Date(); const diffMs=now.getTime()-d.getTime(); const diffSec=Math.floor(diffMs/1000); const diffMin=Math.floor(diffSec/60); const diffHr=Math.floor(diffMin/60); const diffDay=Math.floor(diffHr/24); let rel=''; if(diffSec<60) rel='Just now'; else if(diffMin<60) rel=`${diffMin}m ago`; else if(diffHr<24) rel=`${diffHr}h ago`; else if(diffDay<7) rel=`${diffDay}d ago`; else rel=d.toLocaleDateString(); const localTime=d.toLocaleString(undefined,{ month:'short', day:'numeric', hour:'numeric', minute:'2-digit', hour12:true }); return `${rel} • ${localTime}`; }catch{ return new Date(iso).toLocaleString(); } }

export default function DMsPage(){
  const [supabase,setSupabase]=useState<any>(null);
  const [profile,setProfile]=useState<any>(null);
  const [dms,setDms]=useState<any[]>([]);
  const [selected,setSelected]=useState<string|null>(null);
  const [reply,setReply]=useState('');
  const [search,setSearch]=useState('');
  const [mounted,setMounted]=useState(false);

  useEffect(()=>{
    setMounted(true);
    const sb = getSupabase();
    if(sb) setSupabase(sb);
    const s=typeof window!=='undefined'? localStorage.getItem('nkc_profile_tiered_40') || localStorage.getItem('nkc_profile') : null;
    if(s){ try{ setProfile(JSON.parse(s)); }catch{} }
  },[]);

  const loadDMs = async ()=>{
    if(!supabase || !profile?.full_name) return;
    const {data}=await supabase.from('dms').select('*').or(`from_user.eq.${profile.full_name},to_user.eq.${profile.full_name}`).order('created_at',{ascending:false}).limit(200);
    if(data) setDms(data);
  };

  useEffect(()=>{ if(profile && supabase){ loadDMs(); const int=setInterval(loadDMs,3000); return()=>clearInterval(int); } },[profile, supabase]);

  const convos: Record<string, any[]> = {};
  dms.forEach((m:any)=>{ const other = m.from_user===profile?.full_name ? m.to_user : m.from_user; if(!convos[other]) convos[other]=[]; convos[other].push(m); });
  const sortedConvoKeys = Object.keys(convos).sort((a,b)=>{ const latestA = convos[a][0]?.created_at || ''; const latestB = convos[b][0]?.created_at || ''; return new Date(latestB).getTime() - new Date(latestA).getTime(); }).filter(k=> !search || k.toLowerCase().includes(search.toLowerCase()));
  const activeMessages = selected ? (convos[selected]||[]).slice().reverse() : [];
  const sendReply = async ()=>{
    if(!supabase || !selected || !reply.trim() || !profile) return;
    const msg=reply.trim(); setReply('');
    try{ await supabase.from('dms').insert({ from_user:profile.full_name, to_user:selected, message:msg, body:msg } as any); loadDMs(); }catch(e:any){ alert('Failed: '+e.message); }
  };

  if(!mounted) return <div className="min-h-screen bg-[#f8f5ee] p-6">Loading...</div>;
  if(!profile) return <div className="min-h-screen bg-[#f8f5ee] p-6"><Link href="/" className="text-sm font-bold">← Back to Feed</Link><p className="mt-6">Please join first.</p></div>;

  return (
    <div className="min-h-screen bg-[#f8f5ee] flex flex-col">
      <header className="bg-white border-b sticky top-0 z-20 px-4 py-3 flex justify-between items-center"><Link href="/" className="font-black">← Meadowbrook • DMs</Link><span className="text-xs">{profile.full_name}</span></header>
      <div className="flex-1 max-w-6xl w-full mx-auto grid grid-cols-1 md:grid-cols-[320px_1fr] gap-4 p-4">
        <div className="bg-white rounded-2xl border h-[calc(100vh-100px)] flex flex-col overflow-hidden">
          <div className="p-3 border-b"><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search people..." className="w-full bg-[#f8f5ee] rounded-full px-4 py-2 text-sm outline-none" /></div>
          <div className="flex-1 overflow-y-auto">{sortedConvoKeys.map(other=>{ const msgs=convos[other]; const last=msgs[0]; return (<button key={other} onClick={()=>setSelected(other)} className={`w-full text-left p-4 border-b hover:bg-black/5 ${selected===other?'bg-[#f8f5ee]':''}`}><p className="font-bold text-sm">{other}</p><p className="text-xs opacity-60 truncate">{last.message||last.body}</p></button>); })}</div>
        </div>
        <div className="bg-white rounded-2xl border h-[calc(100vh-100px)] flex flex-col">
          {!selected ? <div className="flex-1 flex items-center justify-center opacity-50"><p className="font-bold">Select a conversation</p></div> : <>
            <div className="p-4 border-b bg-[#f8f5ee] rounded-t-2xl"><p className="font-black">{selected}</p></div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#f8f5ee]">{activeMessages.map((m:any)=>{ const isMe=m.from_user===profile.full_name; return (<div key={m.id} className={`flex ${isMe?'justify-end':'justify-start'}`}><div className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${isMe?'bg-[#1a3a2f] text-white':'bg-white border'}`}>{m.message||m.body}</div></div>); })}</div>
            <div className="p-3 border-t flex gap-2"><input value={reply} onChange={e=>setReply(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter') sendReply(); }} placeholder="Reply..." className="flex-1 bg-[#f8f5ee] border rounded-full px-4 py-3 text-sm outline-none" /><button onClick={sendReply} className="bg-black text-white px-5 py-3 rounded-full text-sm font-black">Send</button></div>
          </>}
        </div>
      </div>
    </div>
  );
}
