
export const dynamic='force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
export async function POST(){ return NextResponse.json({ok:true}); }
